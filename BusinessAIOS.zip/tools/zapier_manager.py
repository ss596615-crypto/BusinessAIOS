# Zap manager placeholder
