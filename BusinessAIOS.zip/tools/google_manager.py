# Google manager placeholder
